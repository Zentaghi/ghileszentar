# Portfolio — Ghiles Zentar

Portfolio statique prêt pour GitHub Pages.

## Mise à jour ultra simple

La majorité du contenu modifiable se trouve dans `data/portfolio.json`.
Ajoute/modifie un projet, une compétence ou une formation, puis :

```bash
git add .
git commit -m "Update portfolio"
git push
```

Le workflow `.github/workflows/pages.yml` republie automatiquement le site.

## Première publication

1. Crée un dépôt GitHub (ex. `portfolio`).
2. Copie ces fichiers dans le dépôt et pousse sur la branche `main`.
3. Dans GitHub : **Settings → Pages → Source → GitHub Actions**.
4. Le prochain push déclenche le déploiement.

## Personnalisation

- Contenu : `data/portfolio.json`
- Design : `assets/style.css`
- Structure : `index.html`
- Rendu dynamique : `assets/app.js`

Aucun framework et aucune clé API ne sont nécessaires.
